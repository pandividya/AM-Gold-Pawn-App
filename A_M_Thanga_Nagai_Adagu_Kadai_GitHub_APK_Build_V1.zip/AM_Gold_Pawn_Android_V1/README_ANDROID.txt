A M Gold Pawn - Android wrapper project

This project packages the existing mobile web app as an Android app using Capacitor.

1. Install Node.js 20+ and Android Studio with Android SDK.
2. In this folder run: npm install
3. Run: npx cap add android
4. Run: npx cap sync android
5. Open the android folder in Android Studio.
6. Build a debug APK from Build > Build APK(s), or a signed release APK from Generate Signed Bundle / APK.

Supabase URL and publishable key are already present in the app source. Do NOT add a Supabase secret/service_role key to the app.
