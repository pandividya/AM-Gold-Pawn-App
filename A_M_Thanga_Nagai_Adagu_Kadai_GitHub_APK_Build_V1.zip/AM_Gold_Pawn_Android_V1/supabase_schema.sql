-- Supabase database schema for A M தங்க நகை அடகு கடை
create table if not exists customers (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 mobile text not null,
 address text,
 id_type text,
 id_number text,
 created_at timestamptz default now()
);
create table if not exists loans (
 id uuid primary key default gen_random_uuid(),
 bill_no text unique not null,
 customer_id uuid references customers(id),
 metal text not null check (metal in ('GOLD','SILVER')),
 item text,
 gross_weight numeric(12,3) default 0,
 stone_weight numeric(12,3) default 0,
 net_weight numeric(12,3) default 0,
 purity text,
 gold_rate numeric(14,2) default 0,
 loan_amount numeric(14,2) not null,
 interest_percent numeric(5,2) not null,
 loan_months integer default 0,
 due_date date,
 notes text,
 status text default 'ACTIVE',
 principal_paid numeric(14,2) default 0,
 created_at timestamptz default now()
);
create table if not exists payments (
 id uuid primary key default gen_random_uuid(),
 loan_id uuid references loans(id),
 amount numeric(14,2) not null,
 payment_type text not null,
 payment_date date default current_date,
 created_at timestamptz default now()
);
-- Business defaults:
-- GOLD monthly interest = 2%
-- SILVER monthly interest = 4%
-- Shop: A M தங்க நகை அடகு கடை
-- Address: T. சுக்காம்பட்டி, தமிழ்நாடு
-- Phone: 8973378328
